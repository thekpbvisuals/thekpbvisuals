# The KPB Visuals & Client Specifications

## 1. Agency Brand Identity (The KPB Visuals)
- **Brand Name:** The KPB Visuals
- **Tagline:** Websites & Social Media
- **Core Specialization:** High-Converting Websites & Engaging Social Media Graphics
- **Aesthetic:** Ultra-minimalist, clean, modern, warm-editorial.
- **Agency Color Palette:**
  - **Linen Cream / Warm White:** `#FBF9F5` / `#FAF7F2` (Clean, warm backdrop)
  - **Warm Beige:** `#E6DFD5` / `#D9CEBE` (Soft contrast)
  - **Earthy Khaki:** `#A39171` / `#7C6958` (Accents)
  - **Espresso Taupe:** `#2A1E17` / `#1F1611` (Line art & bold typography)
- **Master Mark:** Minimalist dual-device emblem (Laptop representing Websites + Smartphone representing Social Media) with clean KPB monogram.
- **Messenger Contact:** `https://www.facebook.com/p.kxts/`
- **Email Contact:** `kpabuhay@gmail.com`
- **Project Turnaround:** 7–10 Business Days
- **Credit Line:** *"Designed & Developed with pride by The KPB Visuals"*

---

## 2. Client Project Identity (Merilles Chess Academy)
- **Client:** Coach Merilles
- **Industry:** Competitive Chess Coaching & Youth Scholastic Academy
- **Target Market:** Philippines (Kids, Teens, Tournament Competitors)
- **Academy Color Scheme (Separate from Agency):**
  - **Primary:** Royal Blue (`#1E3A8A` / `#0F1D4A`)
  - **Accent:** Gold (`#D97706` / `#F59E0B`)
  - **Base:** Crisp White (`#FFFFFF`)
- **Academy Typography:**
  - **Headlines:** `Montserrat`
  - **Schedules & UI:** `Inter`
  - **Body & Bios:** `Open Sans`
- **Key Features:**
  - Conflict-free schedule booking (zero double-booking)
  - Student registration & rating collection
  - GCash & Bank Transfer manual payment verification
  - Coach admin verification portal

---
*Maintained by The KPB Visuals. Auto-saved in Google AI Studio.*
