import React, { useState } from 'react';
import { KPB_LOGO_DATA_URL } from './assets/logoBase64';
import { 
  Laptop, 
  Smartphone, 
  Check, 
  ArrowRight, 
  MessageSquare, 
  Mail, 
  Clock, 
  ExternalLink, 
  Send, 
  CheckCircle2
} from 'lucide-react';

export default function App() {
  const [formData, setFormData] = useState({
    name: '',
    businessName: '',
    email: '',
    phone: '',
    service: 'website',
    budget: '10k',
    notes: ''
  });
  const [formSubmitted, setFormSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name || !formData.email) return;
    setFormSubmitted(true);
  };

  return (
    <div className="min-h-screen bg-[#FBF9F5] text-[#2A1E17] font-sans selection:bg-[#E8DCCB] selection:text-[#1F1611]">
      {/* Top Simple Announcement */}
      <div className="bg-[#2A1E17] text-[#FBF9F5] text-xs py-2 px-4 text-center font-ui">
        <div className="max-w-5xl mx-auto flex items-center justify-center space-x-2">
          <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
          <span>Open for new projects • 7 to 10 days turnaround per site</span>
        </div>
      </div>

      {/* Navigation */}
      <nav className="border-b border-[#E8DFD3] bg-white/95 sticky top-0 z-50">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl overflow-hidden border border-[#D9CEBE] bg-[#FBF9F5] p-0.5 shadow-sm">
              <img 
                src={KPB_LOGO_DATA_URL} 
                alt="The KPB Visuals Logo" 
                className="w-full h-full object-cover rounded-lg"
              />
            </div>
            <div>
              <span className="font-bold tracking-wider text-base text-[#2A1E17] block leading-none">
                THE KPB VISUALS
              </span>
              <span className="text-[10px] text-[#7C6958]">Websites & Social Media</span>
            </div>
          </div>

          <div className="hidden sm:flex items-center space-x-6 text-xs font-medium text-[#6E5948]">
            <a href="#services" className="hover:text-[#2A1E17]">What I Do</a>
            <a href="#work" className="hover:text-[#2A1E17]">Sample Work</a>
            <a href="#pricing" className="hover:text-[#2A1E17]">Pricing</a>
            <a href="#contact" className="hover:text-[#2A1E17]">Contact</a>
          </div>

          <a 
            href="#contact" 
            className="px-3.5 py-1.5 rounded-lg text-xs font-semibold bg-[#2A1E17] text-[#FBF9F5] hover:bg-[#3E2D23] transition-colors"
          >
            Send a Message
          </a>
        </div>
      </nav>

      {/* Hero Section */}
      <header className="pt-12 pb-16 px-4 sm:px-6">
        <div className="max-w-3xl mx-auto text-center space-y-5">
          {/* Prominent Official Brand Logo */}
          <div className="flex justify-center mb-2">
            <div className="w-28 h-28 sm:w-36 sm:h-36 rounded-2xl overflow-hidden border-2 border-[#D9CEBE] bg-[#FBF9F5] p-1 shadow-md hover:scale-105 transition-transform duration-300">
              <img 
                src={KPB_LOGO_DATA_URL} 
                alt="The KPB Visuals Logo" 
                className="w-full h-full object-cover rounded-xl"
              />
            </div>
          </div>

          <span className="text-xs font-semibold tracking-wide text-[#7C6958] uppercase block">
            Freelance Web & Social Media Design
          </span>

          <h1 className="text-3xl sm:text-5xl font-extrabold text-[#1F1611] tracking-tight leading-tight">
            Simple, clean websites and social media graphics for your business.
          </h1>

          <p className="text-sm sm:text-base text-[#6E5948] leading-relaxed max-w-xl mx-auto">
            I help small businesses, academies, and coaches create easy-to-use websites and clear social media posts. Clean design, mobile-friendly, and straightforward.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-3">
            <a 
              href="#contact" 
              className="w-full sm:w-auto px-6 py-3 rounded-xl font-semibold text-xs sm:text-sm bg-[#2A1E17] text-[#FBF9F5] hover:bg-[#3E2D23] transition-colors flex items-center justify-center space-x-2"
            >
              <span>Talk About Your Project</span>
              <ArrowRight className="w-4 h-4" />
            </a>
            <a 
              href="#pricing" 
              className="w-full sm:w-auto px-6 py-3 rounded-xl font-semibold text-xs sm:text-sm bg-white text-[#2A1E17] border border-[#D9CEBE] hover:bg-[#F3EDE3] transition-colors"
            >
              <span>See Rates</span>
            </a>
          </div>

          {/* Simple points */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-8 text-left text-xs text-[#5C4A3C]">
            <div className="p-3.5 rounded-xl bg-white border border-[#E8DFD3]">
              <span className="font-bold text-[#2A1E17] block mb-0.5">Mobile Friendly</span>
              <span>Looks good and works properly on smartphones.</span>
            </div>
            <div className="p-3.5 rounded-xl bg-white border border-[#E8DFD3]">
              <span className="font-bold text-[#2A1E17] block mb-0.5">GCash & Payments</span>
              <span>Clear instructions for customers to pay via GCash or bank.</span>
            </div>
            <div className="p-3.5 rounded-xl bg-white border border-[#E8DFD3]">
              <span className="font-bold text-[#2A1E17] block mb-0.5">7–10 Days</span>
              <span>Realistic timeline to get things done right.</span>
            </div>
          </div>
        </div>
      </header>

      {/* Services Section */}
      <section id="services" className="py-14 px-4 sm:px-6 bg-[#F3EDE3]/40 border-y border-[#E8DFD3]">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="space-y-1">
            <span className="text-xs uppercase font-bold tracking-wider text-[#8C7A68]">Services</span>
            <h2 className="text-2xl sm:text-3xl font-bold text-[#1F1611]">What I Can Do For You</h2>
            <p className="text-xs sm:text-sm text-[#6E5948]">
              I keep things simple so you get exactly what you need without paying for extras you won't use.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Service 1 */}
            <div className="p-6 rounded-2xl bg-white border border-[#E2D6C5] space-y-4">
              <div className="w-10 h-10 rounded-xl bg-[#FBF9F5] border border-[#DDD1BE] flex items-center justify-center text-[#2A1E17]">
                <Laptop className="w-5 h-5 text-[#8C7A68]" />
              </div>
              <h3 className="text-xl font-bold text-[#1F1611]">Website Creation</h3>
              <p className="text-xs text-[#6E5948] leading-relaxed">
                A custom website that introduces what you do, lists your services or classes, and lets customers reach out or book slots.
              </p>
              <ul className="space-y-2 text-xs text-[#5C4A3C]">
                <li className="flex items-start space-x-2">
                  <Check className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                  <span>Works smoothly on mobile phones, tablets, and laptops.</span>
                </li>
                <li className="flex items-start space-x-2">
                  <Check className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                  <span>Optional schedule picker to prevent double-booking.</span>
                </li>
                <li className="flex items-start space-x-2">
                  <Check className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                  <span>Payment page showing your GCash QR and bank accounts.</span>
                </li>
                <li className="flex items-start space-x-2">
                  <Check className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                  <span>Contact form and direct link to your Facebook Messenger.</span>
                </li>
              </ul>
            </div>

            {/* Service 2 */}
            <div className="p-6 rounded-2xl bg-white border border-[#E2D6C5] space-y-4">
              <div className="w-10 h-10 rounded-xl bg-[#FBF9F5] border border-[#DDD1BE] flex items-center justify-center text-[#2A1E17]">
                <Smartphone className="w-5 h-5 text-[#8C7A68]" />
              </div>
              <h3 className="text-xl font-bold text-[#1F1611]">Social Media Graphics</h3>
              <p className="text-xs text-[#6E5948] leading-relaxed">
                Clean and readable graphics for your Facebook page or Instagram so your business looks credible and organized.
              </p>
              <ul className="space-y-2 text-xs text-[#5C4A3C]">
                <li className="flex items-start space-x-2">
                  <Check className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                  <span>Class schedules, tournament flyers, or service posters.</span>
                </li>
                <li className="flex items-start space-x-2">
                  <Check className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                  <span>Facebook cover banners and profile graphics.</span>
                </li>
                <li className="flex items-start space-x-2">
                  <Check className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                  <span>Consistent colors and readable fonts.</span>
                </li>
                <li className="flex items-start space-x-2">
                  <Check className="w-3.5 h-3.5 text-emerald-600 mt-0.5 shrink-0" />
                  <span>Delivered ready-to-upload in high quality.</span>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* Sample Work Section */}
      <section id="work" className="py-14 px-4 sm:px-6">
        <div className="max-w-4xl mx-auto space-y-6">
          <div className="space-y-1">
            <span className="text-xs uppercase font-bold tracking-wider text-[#8C7A68]">Current Project</span>
            <h2 className="text-2xl sm:text-3xl font-bold text-[#1F1611]">Merilles Chess Academy</h2>
            <p className="text-xs sm:text-sm text-[#6E5948]">
              Here is an example of what I'm building for a local chess coach.
            </p>
          </div>

          <div className="p-6 sm:p-8 rounded-2xl bg-white border border-[#D9CEBE] space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-[#F2ECE1] pb-3">
              <div>
                <h4 className="font-bold text-base text-[#1F1611]">Coaching & Enrollment Website</h4>
                <p className="text-xs text-[#7C6958]">Client: Coach Merilles • Philippine Chess Coaching</p>
              </div>
              <span className="px-2.5 py-1 rounded-md text-[11px] font-semibold bg-[#F3EDE3] text-[#2A1E17]">
                In Progress
              </span>
            </div>

            <p className="text-xs sm:text-sm text-[#5C4A3C] leading-relaxed">
              Instead of answering every enrollment inquiry manually on Facebook, Coach Merilles needed a single website where students can see his achievements, pick an open class schedule, and send their GCash reference number to confirm their slot.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs">
              <div className="p-3 rounded-xl bg-[#FBF9F5] border border-[#E8DFD3]">
                <strong className="block text-[#2A1E17]">Achievements List</strong>
                <span className="text-[#7C6958] text-[11px]">Trophies, FIDE title, and past students.</span>
              </div>
              <div className="p-3 rounded-xl bg-[#FBF9F5] border border-[#E8DFD3]">
                <strong className="block text-[#2A1E17]">Slot Booking</strong>
                <span className="text-[#7C6958] text-[11px]">Students pick a time without double-booking.</span>
              </div>
              <div className="p-3 rounded-xl bg-[#FBF9F5] border border-[#E8DFD3]">
                <strong className="block text-[#2A1E17]">GCash Verification</strong>
                <span className="text-[#7C6958] text-[11px]">Coach verifies payments on his phone.</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-14 px-4 sm:px-6 bg-[#F3EDE3]/40 border-t border-[#E8DFD3]">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="space-y-1">
            <span className="text-xs uppercase font-bold tracking-wider text-[#8C7A68]">Rates</span>
            <h2 className="text-2xl sm:text-3xl font-bold text-[#1F1611]">Simple Pricing</h2>
            <p className="text-xs sm:text-sm text-[#6E5948]">
              No confusing tiers. Here is what I charge based on what you need.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {/* Package 1 */}
            <div className="p-6 rounded-2xl bg-white border border-[#E2D6C5] flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <span className="text-xs font-bold text-[#8C7A68] uppercase block">Starter</span>
                <h3 className="text-xl font-bold text-[#1F1611]">Basic Website</h3>
                <div>
                  <span className="text-2xl font-bold text-[#2A1E17]">₱10,000</span>
                  <span className="text-xs text-[#7C6958] ml-1">one-time</span>
                </div>
                <p className="text-xs text-[#6E5948]">
                  Great for a business that just needs a clean, professional page with details and a contact form.
                </p>
                <ul className="space-y-2 text-xs text-[#5C4A3C] pt-2 border-t border-[#F2ECE1]">
                  <li className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>Single-page custom layout</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>Mobile friendly</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>Contact form & Messenger link</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>7–10 days turnaround</span>
                  </li>
                </ul>
              </div>
              <a 
                href="#contact" 
                className="w-full py-2.5 rounded-lg text-xs font-semibold text-center bg-[#FBF9F5] border border-[#D9CEBE] text-[#2A1E17] hover:bg-[#2A1E17] hover:text-white transition-colors"
              >
                Inquire About Basic
              </a>
            </div>

            {/* Package 2 */}
            <div className="p-6 rounded-2xl bg-white border-2 border-[#2A1E17] shadow-sm flex flex-col justify-between space-y-4 relative">
              <div className="space-y-3">
                <span className="text-xs font-bold text-[#A39171] uppercase block">Most Requested</span>
                <h3 className="text-xl font-bold text-[#1F1611]">Website + Booking</h3>
                <div>
                  <span className="text-2xl font-bold text-[#2A1E17]">₱15,000</span>
                  <span className="text-xs text-[#7C6958] ml-1">one-time</span>
                </div>
                <p className="text-xs text-[#6E5948]">
                  For coaches, clinics, or tutors who need clients to pick schedule slots and submit payment proof.
                </p>
                <ul className="space-y-2 text-xs text-[#5C4A3C] pt-2 border-t border-[#F2ECE1]">
                  <li className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>Everything in Basic</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>Class schedule picker (no double-booking)</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>GCash / bank payment details & reference code</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>Admin screen to approve or cancel bookings</span>
                  </li>
                </ul>
              </div>
              <a 
                href="#contact" 
                className="w-full py-2.5 rounded-lg text-xs font-semibold text-center bg-[#2A1E17] text-[#FBF9F5] hover:bg-[#3E2D23] transition-colors"
              >
                Inquire About Booking
              </a>
            </div>

            {/* Package 3 */}
            <div className="p-6 rounded-2xl bg-white border border-[#E2D6C5] flex flex-col justify-between space-y-4">
              <div className="space-y-3">
                <span className="text-xs font-bold text-[#8C7A68] uppercase block">Monthly Help</span>
                <h3 className="text-xl font-bold text-[#1F1611]">Updates & Social Posts</h3>
                <div>
                  <span className="text-2xl font-bold text-[#2A1E17]">₱2,500</span>
                  <span className="text-xs text-[#7C6958] ml-1">/ month</span>
                </div>
                <p className="text-xs text-[#6E5948]">
                  If you need someone to update your website regularly and make graphics for your social media.
                </p>
                <ul className="space-y-2 text-xs text-[#5C4A3C] pt-2 border-t border-[#F2ECE1]">
                  <li className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>Schedule & text changes whenever you need</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>4 custom social media post graphics a month</span>
                  </li>
                  <li className="flex items-center space-x-2">
                    <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
                    <span>Direct messaging whenever you have questions</span>
                  </li>
                </ul>
              </div>
              <a 
                href="#contact" 
                className="w-full py-2.5 rounded-lg text-xs font-semibold text-center bg-[#FBF9F5] border border-[#D9CEBE] text-[#2A1E17] hover:bg-[#2A1E17] hover:text-white transition-colors"
              >
                Inquire About Monthly
              </a>
            </div>
          </div>

          {/* Honest Note About Domain and Hosting */}
          <div className="p-4 rounded-xl bg-white border border-[#D9CEBE] text-xs text-[#6E5948] space-y-1">
            <strong className="text-[#2A1E17] block">A quick note about domain and hosting:</strong>
            <p>
              The prices above cover my work building and designing your website. For your domain name (like yourbusiness.com) and hosting, you will pay for those directly to the provider (such as Namecheap or Cloudflare). Prices vary depending on what name and plan you choose. I will help you set it all up so you own your account directly.
            </p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section id="contact" className="py-14 px-4 sm:px-6 bg-[#2A1E17] text-[#FBF9F5]">
        <div className="max-w-4xl mx-auto space-y-8">
          <div className="space-y-1 text-center sm:text-left">
            <span className="text-xs uppercase font-bold tracking-wider text-[#D8C3A5]">Get In Touch</span>
            <h2 className="text-2xl sm:text-3xl font-bold text-white">Let's Talk About Your Project</h2>
            <p className="text-xs sm:text-sm text-[#D8C3A5]/80">
              Feel free to message me on Facebook Messenger or send an email below.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-5 gap-6 bg-[#1F1611] p-6 sm:p-8 rounded-2xl border border-[#483323]">
            {/* Contact links */}
            <div className="md:col-span-2 space-y-5">
              <div>
                <h4 className="font-bold text-white text-base">The KPB Visuals</h4>
                <p className="text-xs text-[#baa89a]">Websites & Social Media Graphics</p>
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <span className="text-[#baa89a] block text-[11px]">Facebook Messenger:</span>
                  <a 
                    href="https://www.facebook.com/p.kxts/" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-amber-300 hover:underline font-medium inline-flex items-center space-x-1 mt-0.5"
                  >
                    <span>facebook.com/p.kxts</span>
                    <ExternalLink className="w-3 h-3" />
                  </a>
                </div>

                <div>
                  <span className="text-[#baa89a] block text-[11px]">Email:</span>
                  <a href="mailto:kpabuhay@gmail.com" className="text-white hover:underline font-medium">
                    kpabuhay@gmail.com
                  </a>
                </div>

                <div>
                  <span className="text-[#baa89a] block text-[11px]">Timeline:</span>
                  <span className="text-white">7 to 10 days per website</span>
                </div>
              </div>

              <a 
                href="https://www.facebook.com/p.kxts/" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="w-full py-2.5 px-3 rounded-lg bg-[#0084FF] hover:bg-[#0073e6] text-white font-semibold text-xs flex items-center justify-center space-x-2 transition-colors"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>Message Me on Facebook</span>
              </a>
            </div>

            {/* Simple Form */}
            <div className="md:col-span-3">
              {formSubmitted ? (
                <div className="h-full flex flex-col items-center justify-center text-center p-6 bg-[#2A1E17] rounded-xl border border-emerald-500/30 space-y-2">
                  <CheckCircle2 className="w-8 h-8 text-emerald-400" />
                  <h4 className="font-bold text-white text-sm">Message Sent!</h4>
                  <p className="text-xs text-[#d8c3a5]">
                    Thanks, <strong>{formData.name}</strong>. I received your note and will get back to you soon. You can also message me anytime on Facebook!
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-3 text-xs">
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[11px] text-[#d8c3a5]">Your Name *</label>
                      <input 
                        type="text" 
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({...formData, name: e.target.value})}
                        placeholder="Your name"
                        className="w-full px-3 py-2 rounded-lg bg-[#2A1E17] border border-[#483323] text-white placeholder-stone-500 focus:outline-none focus:border-amber-400"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[11px] text-[#d8c3a5]">Business / Brand Name</label>
                      <input 
                        type="text" 
                        value={formData.businessName}
                        onChange={(e) => setFormData({...formData, businessName: e.target.value})}
                        placeholder="What is your business?"
                        className="w-full px-3 py-2 rounded-lg bg-[#2A1E17] border border-[#483323] text-white placeholder-stone-500 focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div className="space-y-1">
                      <label className="text-[11px] text-[#d8c3a5]">Email *</label>
                      <input 
                        type="email" 
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({...formData, email: e.target.value})}
                        placeholder="your@email.com"
                        className="w-full px-3 py-2 rounded-lg bg-[#2A1E17] border border-[#483323] text-white placeholder-stone-500 focus:outline-none focus:border-amber-400"
                      />
                    </div>
                    <div className="space-y-1">
                      <label className="text-[11px] text-[#d8c3a5]">Mobile Number</label>
                      <input 
                        type="tel" 
                        value={formData.phone}
                        onChange={(e) => setFormData({...formData, phone: e.target.value})}
                        placeholder="09XX-XXX-XXXX"
                        className="w-full px-3 py-2 rounded-lg bg-[#2A1E17] border border-[#483323] text-white placeholder-stone-500 focus:outline-none focus:border-amber-400"
                      />
                    </div>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] text-[#d8c3a5]">What do you need?</label>
                    <select 
                      value={formData.service}
                      onChange={(e) => setFormData({...formData, service: e.target.value})}
                      className="w-full px-3 py-2 rounded-lg bg-[#2A1E17] border border-[#483323] text-white focus:outline-none focus:border-amber-400"
                    >
                      <option value="website">Basic Website (₱10,000)</option>
                      <option value="booking">Website with Booking / Schedules (₱15,000)</option>
                      <option value="social">Social Media Graphics</option>
                      <option value="monthly">Monthly Updates & Posts (₱2,500/mo)</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="text-[11px] text-[#d8c3a5]">Tell me a little about your project</label>
                    <textarea 
                      rows={3}
                      value={formData.notes}
                      onChange={(e) => setFormData({...formData, notes: e.target.value})}
                      placeholder="What kind of website or graphics are you looking for?"
                      className="w-full px-3 py-2 rounded-lg bg-[#2A1E17] border border-[#483323] text-white placeholder-stone-500 focus:outline-none focus:border-amber-400 resize-none"
                    />
                  </div>

                  <button 
                    type="submit"
                    className="w-full py-2.5 rounded-lg font-semibold text-xs bg-amber-400 hover:bg-amber-300 text-stone-950 transition-colors flex items-center justify-center space-x-2"
                  >
                    <Send className="w-3.5 h-3.5" />
                    <span>Send Message</span>
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-[#E8DFD3] py-8 px-4 sm:px-6 text-xs text-[#7C6958]">
        <div className="max-w-5xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center space-x-2.5">
            <div className="w-9 h-9 rounded-lg overflow-hidden border border-[#D9CEBE] bg-[#FBF9F5] p-0.5 shadow-sm">
              <img 
                src={KPB_LOGO_DATA_URL} 
                alt="The KPB Visuals Logo" 
                className="w-full h-full object-cover rounded-md"
              />
            </div>
            <span className="font-bold text-[#2A1E17]">THE KPB VISUALS</span>
          </div>

          <p className="text-[11px] text-[#8C7A68]">
            Websites & Social Media Graphics • <a href="https://www.facebook.com/p.kxts/" target="_blank" rel="noopener noreferrer" className="hover:underline text-[#2A1E17]">facebook.com/p.kxts</a>
          </p>
        </div>
      </footer>
    </div>
  );
}
